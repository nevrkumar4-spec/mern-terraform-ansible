variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Prefix used for resource names and tags"
  type        = string
  default     = "travelmemory"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.20.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR block for the public (web) subnet"
  type        = string
  default     = "10.20.1.0/24"
}

variable "private_subnet_cidr" {
  description = "CIDR block for the private (database) subnet"
  type        = string
  default     = "10.20.2.0/24"
}

variable "web_instance_type" {
  description = "EC2 type for the web server (the React build needs ~1.5 GB RAM)"
  type        = string
  default     = "t3.small"
}

variable "db_instance_type" {
  description = "EC2 type for the MongoDB server"
  type        = string
  default     = "t3.micro"
}

variable "admin_cidr" {
  description = "CIDR allowed to SSH to the web server. Empty = auto-detect this machine's public IP (/32)."
  type        = string
  default     = ""
}
