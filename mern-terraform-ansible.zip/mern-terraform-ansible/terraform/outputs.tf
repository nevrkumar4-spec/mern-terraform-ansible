output "web_public_ip" {
  description = "Public IP of the web server EC2 instance"
  value       = aws_instance.web.public_ip
}

output "app_url" {
  description = "TravelMemory URL"
  value       = "http://${aws_instance.web.public_ip}"
}

output "db_private_ip" {
  description = "Private IP of the MongoDB server (not internet-reachable)"
  value       = aws_instance.db.private_ip
}

output "vpc_id" {
  value = aws_vpc.main.id
}

output "nat_gateway_public_ip" {
  description = "Egress IP used by the private subnet"
  value       = aws_nat_gateway.nat.public_ip
}

output "admin_cidr" {
  description = "CIDR allowed to SSH to the web server"
  value       = local.admin_cidr
}

output "ssh_web" {
  value = "ssh -i ansible/${var.project_name}-key.pem ubuntu@${aws_instance.web.public_ip}"
}

output "ssh_db_via_bastion" {
  value = "ssh -i ansible/${var.project_name}-key.pem -J ubuntu@${aws_instance.web.public_ip} ubuntu@${aws_instance.db.private_ip}"
}
