# One role per tier, both least-privilege AWS managed policies:
#  - SSM Session Manager (break-glass shell without opening SSH further)
#  - CloudWatch agent (ship logs/metrics)
data "aws_iam_policy_document" "ec2_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

locals {
  ec2_managed_policies = [
    "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore",
    "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy",
  ]
  tiers = toset(["web", "db"])
}

resource "aws_iam_role" "ec2" {
  for_each           = local.tiers
  name               = "${var.project_name}-${each.key}-ec2-role"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume.json
}

resource "aws_iam_role_policy_attachment" "ec2" {
  for_each = {
    for pair in setproduct(local.tiers, local.ec2_managed_policies) :
    "${pair[0]}|${pair[1]}" => { tier = pair[0], arn = pair[1] }
  }
  role       = aws_iam_role.ec2[each.value.tier].name
  policy_arn = each.value.arn
}

resource "aws_iam_instance_profile" "ec2" {
  for_each = local.tiers
  name     = "${var.project_name}-${each.key}-profile"
  role     = aws_iam_role.ec2[each.key].name
}
